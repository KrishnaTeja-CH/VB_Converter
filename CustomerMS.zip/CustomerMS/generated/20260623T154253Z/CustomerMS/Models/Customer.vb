Public Class Customer
    Public Property Id As Integer
    Public Property Name As String
    Public Property Email As String

    Private _phone As String
    Public Property Phone As String
        Get
            Return _phone
        End Get
        Set(value As String)
            _phone = FormatPhone(value)
        End Set
    End Property

    Private Function FormatPhone(input As String) As String
        If String.IsNullOrEmpty(input) Then Return String.Empty
        Dim cleaned As String = System.Text.RegularExpressions.Regex.Replace(input, "[^\d]", "")
        Select Case cleaned.Length
            Case 10
                Return $"({cleaned.Substring(0, 3)}) {cleaned.Substring(3, 3)}-{cleaned.Substring(6)}"
            Case 11
                Return $"{cleaned.Substring(0, 1)} ({cleaned.Substring(1, 3)}) {cleaned.Substring(4, 3)}-{cleaned.Substring(7)}"
            Case 7
                Return $"{cleaned.Substring(0, 3)}-{cleaned.Substring(3)}"
            Case Else
                Return input
        End Select
    End Function

    Public Function DisplayLabel() As String
        Return $"{Name} <{Email}>"
    End Function

    Public Overrides Function ToString() As String
        Return DisplayLabel()
    End Function
End Class