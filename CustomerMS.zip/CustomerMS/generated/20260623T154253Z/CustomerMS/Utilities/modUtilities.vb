Imports System.Text.RegularExpressions
Imports System.IO

Module modUtilities
    Public Function IsValidEmail(email As String) As Boolean
        If String.IsNullOrEmpty(email) Then
            Return False
        End If
        
        Try
            Return Regex.IsMatch(email,
                "^\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z$",
                RegexOptions.IgnoreCase)
        Catch
            Throw New NotSupportedException("MIGRATION_WARNING: Email regex validation failed")
        End Try
    End Function

    Public Function FormatPhone(phone As String) As String
        If String.IsNullOrEmpty(phone) Then
            Return String.Empty
        End If
        
        Dim digitsOnly As String = Regex.Replace(phone, "[^\d]", "")
        
        If digitsOnly.Length = 10 Then
            Return String.Format("({0}) {1}-{2}",
                digitsOnly.Substring(0, 3),
                digitsOnly.Substring(3, 3),
                digitsOnly.Substring(6, 4))
        Else
            Return digitsOnly
        End If
    End Function

    Public Sub LogMessage(message As String)
        Dim logPath As String = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "application.log")
        
        Try
            Using writer As New StreamWriter(logPath, True)
                writer.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}")
            End Using
        Catch ex As Exception
            Throw New NotSupportedException($"MIGRATION_WARNING: Failed to write to log file '{logPath}'")
        End Try
    End Sub
End Module