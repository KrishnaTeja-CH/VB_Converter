Imports System.Text.Json
Imports System.IO
Imports System.Collections.Generic

Module DataPersistence

    Private _customers As List(Of Customer)

    Public Sub LoadCustomers()
        _customers = LoadCustomersFromDisk()
    End Sub

    Public Function GetAllCustomers() As List(Of Customer)
        If _customers Is Nothing Then
            LoadCustomers()
        End If
        Return _customers
    End Function

    Public Function GetCustomerCount() As Integer
        Return GetAllCustomers().Count
    End Function

    Public Sub AddCustomer(customer As Customer)
        GetAllCustomers().Add(customer)
        SaveCustomersToDisk(_customers)
    End Sub

    Public Sub DeleteCustomer(id As Integer)
        Dim cust As Customer = GetAllCustomers().Find(Function(c) c.Id = id)
        If cust IsNot Nothing Then
            _customers.Remove(cust)
            SaveCustomersToDisk(_customers)
        End If
    End Sub

    Public Sub SaveCustomersToDisk(customers As List(Of Customer))
        Try
            Dim jsonText As String = JsonSerializer.Serialize(customers, New JsonSerializerOptions With {.WriteIndented = True})
            Dim filePath As String = GetFilePath()
            File.WriteAllText(filePath, jsonText)
        Catch ex As Exception
            Throw New NotSupportedException("MIGRATION_WARNING: Failed to save to disk - " & ex.Message)
        End Try
    End Sub

    Public Function LoadCustomersFromDisk() As List(Of Customer)
        Dim filePath As String = GetFilePath()
        Dim customers As New List(Of Customer)

        If File.Exists(filePath) Then
            Try
                Dim jsonText As String = File.ReadAllText(filePath)
                customers = JsonSerializer.Deserialize(Of List(Of Customer))(jsonText)
                If customers Is Nothing Then
                    customers = New List(Of Customer)
                End If
            Catch ex As Exception
                Throw New NotSupportedException("MIGRATION_WARNING: Failed to load from disk - " & ex.Message)
            End Try
        Else
            customers = New List(Of Customer)
        End If

        Return customers
    End Function

    Private Function GetFilePath() As String
        Return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "customers.json")
    End Function

End Module