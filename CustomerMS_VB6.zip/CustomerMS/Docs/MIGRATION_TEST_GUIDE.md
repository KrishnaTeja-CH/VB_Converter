# Migration Test Guide

This document maps the application's contents to the specific capabilities
your VB6 → VB.NET pipeline must handle. Use it as a checklist when validating
Phase 1 (semantic extraction) and Phase 2 (code generation).

---

## What each file exercises

| File | Patterns it stresses |
|------|----------------------|
| `frmLogin.frm` | Modal form, event handlers, instance state (`mLoginAttempts`), DAL call, message boxes, `Unload Me` |
| `frmMain.frm` | **Menu system** (nested menus), button + menu handlers calling shared subs, `ListBox.ItemData`, `Screen.MousePointer`, form-to-form calls, `Form_Unload` + `End` |
| `frmCustomer.frm` | **Form-to-form communication** via public `WasSaved` property + `LoadForId` method, add/edit mode flag, `Me.Hide` vs `Unload`, service-layer calls |
| `frmSearch.frm` | Parameterized search, results list, details dialog, hourglass cursor |
| `frmAbout.frm` | Static labels populated from global constants |
| `Customer.cls` | Business entity with property Get/Let, read-only derived property (`FullName`), method (`DisplayText`) |
| `CustomerService.cls` | **Business layer** orchestrating 3 dependencies; custom error raising (`vbObjectError + n`); cross-DLL calls |
| `CustomerDAL.cls` | **ADO**: `Connection`, `Command`, `Recordset`; parameterized INSERT/UPDATE/DELETE; `@@IDENTITY`; `Collection` returns; Null-handling helpers |
| `UserDAL.cls` | Parameterized auth query |
| `DbConnection.cls` | **Connection management**, connection-string building, `Class_Initialize`/`Terminate`, `App.Path` |
| `modGlobals.bas` | **Global variables**, global object instance (`gCustomerService`), app constants |
| `modConfig.bas` | **File I/O**: `Open/Line Input/Print/Close`, key=value parsing, default-file creation, relative-path resolution |
| `modMain.bas` | **`Sub Main`** entry point, startup orchestration |
| `CustomerValidator.cls` | **ActiveX DLL**, public methods, `ByRef` out-parameter, private helpers, string parsing |
| `Logger.cls` | **ActiveX DLL**, `Public Enum`, property Get/Let, file append I/O, optional parameter |

---

## Phase 1 — semantic extraction checklist

Your analysis pass should discover and record:

- [ ] **5 forms** with all controls, captions, positions, and tab order
- [ ] The **menu hierarchy** in frmMain (File / Customer / Help with sub-items)
- [ ] **All event handlers** and the control + event they bind to
- [ ] **5 application classes** + **2 DLL classes** with their public APIs
- [ ] **3 standard modules** including the `Sub Main` startup
- [ ] **Two external ActiveX DLL references** (CustomerValidation, AuditLogger)
      and the ADO reference
- [ ] The **dependency graph**: UI → CustomerService → {Validator, Logger, DAL} → DbConnection → DB
- [ ] **ADO usage**: every Connection/Command/Recordset and each SQL statement
- [ ] **Parameterized queries** and their parameter types
- [ ] **Global variables** in modGlobals and where they are read/written
- [ ] **File I/O** in modConfig and Logger
- [ ] **Business rules** (validation thresholds, max login attempts, email/phone rules)
- [ ] **Form-to-form data flow** (frmMain ↔ frmCustomer via WasSaved/LoadForId)

## Phase 2 — code generation checklist

Your generator should produce VB.NET that:

- [ ] Splits each form into `.vb` + `.Designer.vb` with synchronized control names
- [ ] Recreates the menu as a `MenuStrip` with matching `Handles` wiring
- [ ] Converts ADO to ADO.NET (`SqlConnection`/`SqlCommand`/`SqlDataReader`)
      or your chosen provider (SQLite / PostgreSQL)
- [ ] Maps `@@IDENTITY` → `SCOPE_IDENTITY()` / `last_insert_rowid()` / `RETURNING`
- [ ] Replaces the two ActiveX DLLs with .NET class libraries (or inlines them)
- [ ] Preserves the layered architecture and the dependency graph
- [ ] Converts `Collection` returns to `List(Of Customer)`
- [ ] Replaces file-based config with `app.config` / `appsettings.json`
- [ ] Preserves all business rules and the form-to-form data flow
- [ ] Adds required `Imports` (System.Data, System.Windows.Forms, System.IO)

---

## Known "traps" intentionally included

These are the things that commonly break naive converters — good for testing
your validation and auto-repair layers:

1. **`[Password]` is a reserved word** in Jet SQL (bracketed in the DDL and
   INSERTs). A converter must keep it quoted/escaped for the target DB.
2. **`@@IDENTITY`** is Access-specific and must be translated, not copied.
3. **`Collection` (1-based)** must become a 0-based `List(Of T)`; loops that
   run `1 To .Count` must be adjusted.
4. **Global object `gCustomerService`** — naive per-file conversion can lose
   the shared instance; the lifecycle must be preserved.
5. **Form-to-form contract** — `frmCustomer.WasSaved` / `LoadForId` is a real
   API the caller depends on; it must survive conversion intact (this is the
   `SetCustomer()`-style failure class).
6. **ActiveX DLL types** (`CustomerValidation.CustomerValidator`,
   `AuditLogger.Logger`) — the converter must resolve these to their
   replacement .NET types, not leave dangling COM references.
7. **`ByRef ErrorMessage As String`** out-parameter in `ValidateCustomer`
   must map to a `ByRef` parameter or a return tuple/struct.
8. **`Public Enum LogLevel`** in a DLL must be regenerated in the .NET library.

---

## Suggested test sequence

1. Run Phase 1 on this project → inspect the symbol table / spec.
   Confirm every item in the Phase 1 checklist appears.
2. Run Phase 2 → build the generated solution.
   Confirm it compiles with zero errors.
3. Point the generated app at a migrated database (SQL Server / SQLite).
4. Verify behavior: login, list, add, edit, delete, search, about.
5. Diff behavior against this VB6 original — especially the
   add-then-persist flow and the search results.
