Attribute VB_Name = "modMain"
'==============================================================
' modMain.bas  (Shared Module)
' Application entry point. Loads config, initializes globals,
' then shows the login form.
'==============================================================
Option Explicit

Sub Main()
    On Error GoTo ErrHandler

    ' Load configuration from file into globals.
    LoadConfig

    ' Initialize shared service objects.
    InitGlobals

    ' Show the login form first.
    frmLogin.Show vbModal

    ' If login failed/cancelled, exit.
    If Not gIsLoggedIn Then
        CleanupGlobals
        Exit Sub
    End If

    ' Show the main dashboard.
    frmMain.Show

    Exit Sub

ErrHandler:
    MsgBox "Fatal startup error: " & Err.Description, _
           vbCritical, APP_NAME
    CleanupGlobals
End Sub
