VERSION 5.00
Begin VB.Form frmMain 
   Caption         =   "Customer Management System"
   ClientHeight    =   5400
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7800
   LinkTopic       =   "Form1"
   ScaleHeight     =   5400
   ScaleWidth      =   7800
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdRefresh 
      Caption         =   "&Refresh"
      Height          =   390
      Left            =   6240
      TabIndex        =   6
      Top             =   480
      Width           =   1335
   End
   Begin VB.CommandButton cmdSearch 
      Caption         =   "&Search..."
      Height          =   390
      Left            =   6240
      TabIndex        =   5
      Top             =   1920
      Width           =   1335
   End
   Begin VB.CommandButton cmdDelete 
      Caption         =   "&Delete"
      Height          =   390
      Left            =   6240
      TabIndex        =   4
      Top             =   1440
      Width           =   1335
   End
   Begin VB.CommandButton cmdEdit 
      Caption         =   "&Edit..."
      Height          =   390
      Left            =   6240
      TabIndex        =   3
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdAdd 
      Caption         =   "&Add..."
      Height          =   390
      Left            =   6240
      TabIndex        =   2
      Top             =   480
      Width           =   1335
   End
   Begin VB.ListBox lstCustomers 
      Height          =   4350
      Left            =   240
      TabIndex        =   1
      Top             =   480
      Width           =   5775
   End
   Begin VB.Label lblCount 
      Caption         =   "0 customers"
      Height          =   255
      Left            =   240
      TabIndex        =   0
      Top             =   4950
      Width           =   3855
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFileRefresh 
         Caption         =   "&Refresh"
      End
      Begin VB.Menu mnuFileSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuCustomer 
      Caption         =   "&Customer"
      Begin VB.Menu mnuCustomerAdd 
         Caption         =   "&Add..."
      End
      Begin VB.Menu mnuCustomerEdit 
         Caption         =   "&Edit..."
      End
      Begin VB.Menu mnuCustomerDelete 
         Caption         =   "&Delete"
      End
      Begin VB.Menu mnuCustomerSep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuCustomerSearch 
         Caption         =   "&Search..."
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuHelpAbout 
         Caption         =   "&About..."
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'==============================================================
' frmMain.frm  (UI Layer)
' Main dashboard. Lists customers and routes to maintenance,
' search, and about forms. Uses the global CustomerService.
'==============================================================
Option Explicit

' In-memory list backing the list box, parallel to lstCustomers items.
Private mCustomers As Collection

Private Sub Form_Load()
    Me.Caption = gAppTitle & "  -  User: " & gCurrentUsername
    RefreshList
End Sub

Private Sub Form_Unload(Cancel As Integer)
    CleanupGlobals
    End
End Sub

' Reload all customers from the service into the list box.
Public Sub RefreshList()
    Dim c As Customer
    Dim i As Integer

    On Error GoTo ErrHandler

    Screen.MousePointer = vbHourglass

    Set mCustomers = gCustomerService.GetAllCustomers()

    lstCustomers.Clear
    For i = 1 To mCustomers.Count
        Set c = mCustomers.Item(i)
        lstCustomers.AddItem c.DisplayText
        ' Store the CustomerId in the ItemData for retrieval.
        lstCustomers.ItemData(lstCustomers.NewIndex) = c.CustomerId
    Next i

    lblCount.Caption = mCustomers.Count & " customer(s)"
    Screen.MousePointer = vbDefault
    Exit Sub

ErrHandler:
    Screen.MousePointer = vbDefault
    MsgBox "Failed to load customers: " & Err.Description, vbExclamation, gAppTitle
End Sub

' Returns the CustomerId of the selected list item, or 0 if none.
Private Function SelectedCustomerId() As Long
    If lstCustomers.ListIndex >= 0 Then
        SelectedCustomerId = lstCustomers.ItemData(lstCustomers.ListIndex)
    Else
        SelectedCustomerId = 0
    End If
End Function

' ----- Button handlers -----

Private Sub cmdAdd_Click()
    OpenMaintenance 0
End Sub

Private Sub cmdEdit_Click()
    Dim id As Long
    id = SelectedCustomerId()
    If id = 0 Then
        MsgBox "Please select a customer to edit.", vbInformation, gAppTitle
        Exit Sub
    End If
    OpenMaintenance id
End Sub

Private Sub cmdDelete_Click()
    Dim id As Long
    Dim answer As VbMsgBoxResult

    id = SelectedCustomerId()
    If id = 0 Then
        MsgBox "Please select a customer to delete.", vbInformation, gAppTitle
        Exit Sub
    End If

    answer = MsgBox("Delete the selected customer?", _
                    vbQuestion + vbYesNo, gAppTitle)
    If answer = vbYes Then
        On Error GoTo ErrHandler
        gCustomerService.DeleteCustomer id
        RefreshList
    End If
    Exit Sub

ErrHandler:
    MsgBox "Delete failed: " & Err.Description, vbExclamation, gAppTitle
End Sub

Private Sub cmdSearch_Click()
    frmSearch.Show vbModal, Me
End Sub

Private Sub cmdRefresh_Click()
    RefreshList
End Sub

Private Sub lstCustomers_DblClick()
    cmdEdit_Click
End Sub

' Open the maintenance form for an add (id=0) or edit (id>0).
Private Sub OpenMaintenance(ByVal CustomerId As Long)
    frmCustomer.LoadForId CustomerId
    frmCustomer.Show vbModal, Me
    ' Maintenance form sets a public flag when it saves.
    If frmCustomer.WasSaved Then
        RefreshList
    End If
    Unload frmCustomer
End Sub

' ----- Menu handlers -----

Private Sub mnuFileRefresh_Click()
    RefreshList
End Sub

Private Sub mnuFileExit_Click()
    Unload Me
End Sub

Private Sub mnuCustomerAdd_Click()
    cmdAdd_Click
End Sub

Private Sub mnuCustomerEdit_Click()
    cmdEdit_Click
End Sub

Private Sub mnuCustomerDelete_Click()
    cmdDelete_Click
End Sub

Private Sub mnuCustomerSearch_Click()
    cmdSearch_Click
End Sub

Private Sub mnuHelpAbout_Click()
    frmAbout.Show vbModal, Me
End Sub
