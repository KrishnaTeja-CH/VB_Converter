Attribute VB_Name = "modGlobals"
'==============================================================
' modGlobals.bas  (Shared Module)
' Application-wide global variables and constants.
' Demonstrates classic VB6 global state for migration testing.
'==============================================================
Option Explicit

' --- Application constants ---
Public Const APP_NAME As String = "Customer Management System"
Public Const APP_VERSION As String = "1.0.0"

' --- Global session state ---
Public gCurrentUserId As Long
Public gCurrentUsername As String
Public gIsLoggedIn As Boolean

' --- Shared configuration values (loaded from config file) ---
Public gDatabasePath As String
Public gLogPath As String
Public gAppTitle As String

' --- Shared service instance used across forms ---
Public gCustomerService As CustomerService

' Initialize global service objects. Called once at startup.
Public Sub InitGlobals()
    Set gCustomerService = New CustomerService
    gIsLoggedIn = False
    gCurrentUserId = 0
    gCurrentUsername = ""
End Sub

' Release global objects at shutdown.
Public Sub CleanupGlobals()
    Set gCustomerService = Nothing
End Sub
