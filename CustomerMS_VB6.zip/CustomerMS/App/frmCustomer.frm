VERSION 5.00
Begin VB.Form frmCustomer 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Customer Maintenance"
   ClientHeight    =   3120
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4800
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3120
   ScaleWidth      =   4800
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txtFirstName 
      Height          =   330
      Left            =   1560
      TabIndex        =   0
      Top             =   360
      Width           =   3015
   End
   Begin VB.TextBox txtLastName 
      Height          =   330
      Left            =   1560
      TabIndex        =   1
      Top             =   840
      Width           =   3015
   End
   Begin VB.TextBox txtEmail 
      Height          =   330
      Left            =   1560
      TabIndex        =   2
      Top             =   1320
      Width           =   3015
   End
   Begin VB.TextBox txtPhone 
      Height          =   330
      Left            =   1560
      TabIndex        =   3
      Top             =   1800
      Width           =   3015
   End
   Begin VB.CommandButton cmdSave 
      Caption         =   "&Save"
      Default         =   -1  'True
      Height          =   390
      Left            =   1560
      TabIndex        =   4
      Top             =   2520
      Width           =   1455
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   390
      Left            =   3120
      TabIndex        =   5
      Top             =   2520
      Width           =   1455
   End
   Begin VB.Label lblFirstName 
      Caption         =   "First Name:"
      Height          =   255
      Left            =   240
      TabIndex        =   9
      Top             =   420
      Width           =   1215
   End
   Begin VB.Label lblLastName 
      Caption         =   "Last Name:"
      Height          =   255
      Left            =   240
      TabIndex        =   8
      Top             =   900
      Width           =   1215
   End
   Begin VB.Label lblEmail 
      Caption         =   "Email:"
      Height          =   255
      Left            =   240
      TabIndex        =   7
      Top             =   1380
      Width           =   1215
   End
   Begin VB.Label lblPhone 
      Caption         =   "Phone:"
      Height          =   255
      Left            =   240
      TabIndex        =   6
      Top             =   1860
      Width           =   1215
   End
End
Attribute VB_Name = "frmCustomer"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'==============================================================
' frmCustomer.frm  (UI Layer)
' Add/Edit a customer. Communicates with frmMain through the
' public WasSaved property and LoadForId method.
'==============================================================
Option Explicit

Private mCustomerId As Long      ' 0 = add mode, >0 = edit mode
Private mWasSaved As Boolean

' Public read-only flag so the caller knows whether to refresh.
Public Property Get WasSaved() As Boolean
    WasSaved = mWasSaved
End Property

' Called by frmMain before showing. id=0 means add.
Public Sub LoadForId(ByVal CustomerId As Long)
    Dim c As Customer

    mCustomerId = CustomerId
    mWasSaved = False

    If CustomerId = 0 Then
        Me.Caption = "Add Customer"
        txtFirstName.Text = ""
        txtLastName.Text = ""
        txtEmail.Text = ""
        txtPhone.Text = ""
    Else
        Me.Caption = "Edit Customer"
        On Error GoTo ErrHandler
        Set c = gCustomerService.GetCustomer(CustomerId)
        If Not c Is Nothing Then
            txtFirstName.Text = c.FirstName
            txtLastName.Text = c.LastName
            txtEmail.Text = c.Email
            txtPhone.Text = c.Phone
        End If
    End If
    Exit Sub

ErrHandler:
    MsgBox "Failed to load customer: " & Err.Description, vbExclamation, gAppTitle
End Sub

Private Sub cmdSave_Click()
    Dim c As Customer

    On Error GoTo ErrHandler

    Set c = New Customer
    c.CustomerId = mCustomerId
    c.FirstName = Trim$(txtFirstName.Text)
    c.LastName = Trim$(txtLastName.Text)
    c.Email = Trim$(txtEmail.Text)
    c.Phone = Trim$(txtPhone.Text)

    If mCustomerId = 0 Then
        gCustomerService.AddCustomer c
    Else
        gCustomerService.UpdateCustomer c
    End If

    mWasSaved = True
    Me.Hide
    Exit Sub

ErrHandler:
    ' Validation failures come back as raised errors with a message.
    MsgBox Err.Description, vbExclamation, "Validation"
End Sub

Private Sub cmdCancel_Click()
    mWasSaved = False
    Me.Hide
End Sub
