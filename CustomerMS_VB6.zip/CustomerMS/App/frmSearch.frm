VERSION 5.00
Begin VB.Form frmSearch 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Search Customers"
   ClientHeight    =   4200
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4200
   ScaleWidth      =   6000
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txtSearch 
      Height          =   330
      Left            =   1080
      TabIndex        =   0
      Top             =   240
      Width           =   3135
   End
   Begin VB.CommandButton cmdSearch 
      Caption         =   "&Search"
      Default         =   -1  'True
      Height          =   375
      Left            =   4320
      TabIndex        =   1
      Top             =   240
      Width           =   1455
   End
   Begin VB.ListBox lstResults 
      Height          =   2790
      Left            =   240
      TabIndex        =   2
      Top             =   720
      Width           =   5535
   End
   Begin VB.CommandButton cmdClose 
      Cancel          =   -1  'True
      Caption         =   "&Close"
      Height          =   390
      Left            =   4320
      TabIndex        =   3
      Top             =   3660
      Width           =   1455
   End
   Begin VB.Label lblResultCount 
      Caption         =   "Enter a search term"
      Height          =   255
      Left            =   240
      TabIndex        =   5
      Top             =   3720
      Width           =   3855
   End
   Begin VB.Label lblSearch 
      Caption         =   "Search:"
      Height          =   255
      Left            =   240
      TabIndex        =   4
      Top             =   300
      Width           =   855
   End
End
Attribute VB_Name = "frmSearch"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'==============================================================
' frmSearch.frm  (UI Layer)
' Searches customers by name or email through CustomerService.
' Double-clicking a result shows full details.
'==============================================================
Option Explicit

Private mResults As Collection

Private Sub Form_Load()
    lblResultCount.Caption = "Enter a search term and click Search."
End Sub

Private Sub cmdSearch_Click()
    Dim c As Customer
    Dim i As Integer
    Dim term As String

    On Error GoTo ErrHandler

    term = Trim$(txtSearch.Text)
    If Len(term) = 0 Then
        MsgBox "Please enter a search term.", vbInformation, gAppTitle
        Exit Sub
    End If

    Screen.MousePointer = vbHourglass
    Set mResults = gCustomerService.SearchCustomers(term)

    lstResults.Clear
    For i = 1 To mResults.Count
        Set c = mResults.Item(i)
        lstResults.AddItem c.DisplayText
        lstResults.ItemData(lstResults.NewIndex) = c.CustomerId
    Next i

    lblResultCount.Caption = mResults.Count & " result(s) found."
    Screen.MousePointer = vbDefault
    Exit Sub

ErrHandler:
    Screen.MousePointer = vbDefault
    MsgBox "Search failed: " & Err.Description, vbExclamation, gAppTitle
End Sub

Private Sub lstResults_DblClick()
    Dim id As Long
    Dim c As Customer
    Dim details As String

    If lstResults.ListIndex < 0 Then Exit Sub

    On Error GoTo ErrHandler

    id = lstResults.ItemData(lstResults.ListIndex)
    Set c = gCustomerService.GetCustomer(id)

    If Not c Is Nothing Then
        details = "Customer Details" & vbCrLf & vbCrLf & _
                  "Name:  " & c.FullName & vbCrLf & _
                  "Email: " & c.Email & vbCrLf & _
                  "Phone: " & c.Phone & vbCrLf & _
                  "Created: " & Format$(c.CreatedDate, "yyyy-mm-dd")
        MsgBox details, vbInformation, "Customer #" & c.CustomerId
    End If
    Exit Sub

ErrHandler:
    MsgBox "Failed to load details: " & Err.Description, vbExclamation, gAppTitle
End Sub

Private Sub cmdClose_Click()
    Unload Me
End Sub
