Attribute VB_Name = "modConfig"
'==============================================================
' modConfig.bas  (Shared Module)
' Reads simple key=value configuration from app.config.txt.
' Demonstrates file I/O and parsing for migration testing.
'==============================================================
Option Explicit

Private Const CONFIG_FILE As String = "app.config.txt"

' Load configuration into global variables. Falls back to defaults
' when the file or a key is missing.
Public Sub LoadConfig()
    Dim configPath As String

    On Error GoTo ErrHandler

    configPath = App.Path & "\" & CONFIG_FILE

    ' Defaults first
    gDatabasePath = App.Path & "\Database\CustomerMS.mdb"
    gLogPath = App.Path & "\audit.log"
    gAppTitle = APP_NAME

    If Len(Dir$(configPath)) = 0 Then
        ' No config file: write a default one for next run.
        WriteDefaultConfig configPath
        Exit Sub
    End If

    gDatabasePath = ResolvePath(GetConfigValue(configPath, "DatabasePath", gDatabasePath))
    gLogPath = ResolvePath(GetConfigValue(configPath, "LogPath", gLogPath))
    gAppTitle = GetConfigValue(configPath, "AppTitle", gAppTitle)
    Exit Sub

ErrHandler:
    ' Configuration must never block startup.
End Sub

' Read a single value from the config file by key.
Private Function GetConfigValue(ByVal FilePath As String, _
                                ByVal Key As String, _
                                ByVal DefaultValue As String) As String
    Dim fileNum As Integer
    Dim line As String
    Dim eqPos As Integer
    Dim k As String
    Dim v As String

    On Error GoTo ErrHandler

    GetConfigValue = DefaultValue

    fileNum = FreeFile
    Open FilePath For Input As #fileNum
    Do While Not EOF(fileNum)
        Line Input #fileNum, line
        line = Trim$(line)
        ' Skip comments and blank lines
        If Len(line) > 0 And Left$(line, 1) <> "#" Then
            eqPos = InStr(line, "=")
            If eqPos > 0 Then
                k = Trim$(Left$(line, eqPos - 1))
                v = Trim$(Mid$(line, eqPos + 1))
                If LCase$(k) = LCase$(Key) Then
                    GetConfigValue = v
                    Exit Do
                End If
            End If
        End If
    Loop
    Close #fileNum
    Exit Function

ErrHandler:
    If fileNum <> 0 Then Close #fileNum
    GetConfigValue = DefaultValue
End Function

' Write a starter config file.
Private Sub WriteDefaultConfig(ByVal FilePath As String)
    Dim fileNum As Integer
    On Error Resume Next
    fileNum = FreeFile
    Open FilePath For Output As #fileNum
    Print #fileNum, "# Customer Management System configuration"
    Print #fileNum, "AppTitle=" & APP_NAME
    Print #fileNum, "DatabasePath=.\Database\CustomerMS.mdb"
    Print #fileNum, "LogPath=.\audit.log"
    Close #fileNum
End Sub

' Resolve a relative path (starting with .\) against App.Path.
Private Function ResolvePath(ByVal Path As String) As String
    If Left$(Path, 2) = ".\" Then
        ResolvePath = App.Path & Mid$(Path, 2)
    Else
        ResolvePath = Path
    End If
End Function
