VERSION 5.00
Begin VB.Form frmLogin 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Login - Customer Management System"
   ClientHeight    =   2400
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4800
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2400
   ScaleWidth      =   4800
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txtUsername 
      Height          =   330
      Left            =   1560
      TabIndex        =   0
      Top             =   360
      Width           =   2895
   End
   Begin VB.TextBox txtPassword 
      Height          =   330
      IMEMode         =   3  'DISABLE
      Left            =   1560
      PasswordChar    =   "*"
      TabIndex        =   1
      Top             =   840
      Width           =   2895
   End
   Begin VB.CommandButton cmdLogin 
      Caption         =   "&Login"
      Default         =   -1  'True
      Height          =   390
      Left            =   1560
      TabIndex        =   2
      Top             =   1440
      Width           =   1335
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   390
      Left            =   3120
      TabIndex        =   3
      Top             =   1440
      Width           =   1335
   End
   Begin VB.Label lblUsername 
      Caption         =   "Username:"
      Height          =   255
      Left            =   240
      TabIndex        =   5
      Top             =   420
      Width           =   1215
   End
   Begin VB.Label lblPassword 
      Caption         =   "Password:"
      Height          =   255
      Left            =   240
      TabIndex        =   4
      Top             =   900
      Width           =   1215
   End
   Begin VB.Label lblStatus 
      ForeColor       =   &H000000FF&
      Height          =   255
      Left            =   240
      TabIndex        =   6
      Top             =   1980
      Width           =   4335
   End
End
Attribute VB_Name = "frmLogin"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'==============================================================
' frmLogin.frm  (UI Layer)
' Authenticates the user against the Users table via UserDAL.
'==============================================================
Option Explicit

Private mLoginAttempts As Integer

Private Sub Form_Load()
    mLoginAttempts = 0
    lblStatus.Caption = ""
    Me.Caption = "Login - " & gAppTitle
End Sub

Private Sub cmdLogin_Click()
    Dim userDal As UserDAL
    Dim userId As Long

    On Error GoTo ErrHandler

    If Len(Trim$(txtUsername.Text)) = 0 Then
        lblStatus.Caption = "Please enter a username."
        txtUsername.SetFocus
        Exit Sub
    End If

    If Len(Trim$(txtPassword.Text)) = 0 Then
        lblStatus.Caption = "Please enter a password."
        txtPassword.SetFocus
        Exit Sub
    End If

    Set userDal = New UserDAL
    userId = userDal.Authenticate(Trim$(txtUsername.Text), Trim$(txtPassword.Text))
    Set userDal = Nothing

    If userId > 0 Then
        ' Success: set session globals and close.
        gCurrentUserId = userId
        gCurrentUsername = Trim$(txtUsername.Text)
        gIsLoggedIn = True
        Unload Me
    Else
        mLoginAttempts = mLoginAttempts + 1
        lblStatus.Caption = "Invalid credentials. Attempt " & mLoginAttempts & " of 3."
        txtPassword.Text = ""
        txtPassword.SetFocus

        If mLoginAttempts >= 3 Then
            MsgBox "Maximum login attempts exceeded. The application will close.", _
                   vbCritical, gAppTitle
            gIsLoggedIn = False
            Unload Me
        End If
    End If
    Exit Sub

ErrHandler:
    lblStatus.Caption = "Login error: " & Err.Description
End Sub

Private Sub cmdCancel_Click()
    gIsLoggedIn = False
    Unload Me
End Sub
