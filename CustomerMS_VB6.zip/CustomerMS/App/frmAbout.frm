VERSION 5.00
Begin VB.Form frmAbout 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "About"
   ClientHeight    =   2400
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4200
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2400
   ScaleWidth      =   4200
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdOK 
      Caption         =   "&OK"
      Default         =   -1  'True
      Height          =   390
      Left            =   2760
      TabIndex        =   0
      Top             =   1920
      Width           =   1335
   End
   Begin VB.Label lblAppName 
      Caption         =   "Customer Management System"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   4
      Top             =   240
      Width           =   3735
   End
   Begin VB.Label lblVersion 
      Caption         =   "Version 1.0.0"
      Height          =   255
      Left            =   240
      TabIndex        =   3
      Top             =   720
      Width           =   3735
   End
   Begin VB.Label lblDescription 
      Caption         =   "A sample legacy VB6 application for migration testing."
      Height          =   495
      Left            =   240
      TabIndex        =   2
      Top             =   1080
      Width           =   3735
   End
   Begin VB.Label lblCopyright 
      Caption         =   "Modernization POC"
      Height          =   255
      Left            =   240
      TabIndex        =   1
      Top             =   1680
      Width           =   2415
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'==============================================================
' frmAbout.frm  (UI Layer)
' Static about dialog. Reads version from global constants.
'==============================================================
Option Explicit

Private Sub Form_Load()
    lblAppName.Caption = APP_NAME
    lblVersion.Caption = "Version " & APP_VERSION
End Sub

Private Sub cmdOK_Click()
    Unload Me
End Sub
