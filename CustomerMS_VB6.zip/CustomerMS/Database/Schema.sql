-- ============================================================
-- CustomerMS Database Schema (reference)
-- Target: Microsoft Access / Jet 4.0 (.mdb)
--
-- This file documents the schema. To actually build the .mdb,
-- run CreateDatabase.vbs (Access does not execute .sql files
-- directly). The DDL below is the Jet SQL equivalent and also
-- serves as the reference for migrating to SQL Server / SQLite
-- / PostgreSQL during Phase 2.
-- ============================================================

-- ---------- Users ----------
CREATE TABLE Users (
    UserId      AUTOINCREMENT PRIMARY KEY,
    Username    TEXT(50)  NOT NULL,
    [Password]  TEXT(50)  NOT NULL
);

-- ---------- Customers ----------
CREATE TABLE Customers (
    CustomerId  AUTOINCREMENT PRIMARY KEY,
    FirstName   TEXT(50)  NOT NULL,
    LastName    TEXT(50)  NOT NULL,
    Email       TEXT(100),
    Phone       TEXT(20),
    CreatedDate DATETIME
);

-- ---------- Sample data ----------
INSERT INTO Users (Username, [Password]) VALUES ('admin', 'admin123');
INSERT INTO Users (Username, [Password]) VALUES ('user',  'user123');

INSERT INTO Customers (FirstName, LastName, Email, Phone, CreatedDate)
VALUES ('John', 'Smith', 'john.smith@example.com', '(555) 123-4567', Now());
-- (additional rows seeded by CreateDatabase.vbs)

-- ============================================================
-- Migration notes (Access -> modern DB):
--   AUTOINCREMENT      -> IDENTITY (SQL Server) / SERIAL (PostgreSQL)
--                         / INTEGER PRIMARY KEY AUTOINCREMENT (SQLite)
--   TEXT(n)            -> NVARCHAR(n)
--   DATETIME           -> DATETIME2 / TIMESTAMP
--   Now()              -> GETDATE() / CURRENT_TIMESTAMP
--   @@IDENTITY         -> SCOPE_IDENTITY() / RETURNING / last_insert_rowid()
--   [Password] (kw)    -> rename to PasswordHash and store a hash
-- ============================================================
