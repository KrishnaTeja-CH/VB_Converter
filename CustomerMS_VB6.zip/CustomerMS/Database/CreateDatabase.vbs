'==============================================================
' CreateDatabase.vbs
' Creates CustomerMS.mdb (Access/Jet 4.0) with the Users and
' Customers tables, then seeds sample data.
'
' Run from a command prompt on Windows:
'     cscript CreateDatabase.vbs
'
' Requires: Microsoft Jet 4.0 / ADOX (present on most Windows
' systems with MDAC, or with Access/Office installed).
'==============================================================
Option Explicit

Dim fso, catalog, conn, dbPath, scriptDir

Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
dbPath = scriptDir & "\CustomerMS.mdb"

' Delete existing database so the script is repeatable.
If fso.FileExists(dbPath) Then
    fso.DeleteFile dbPath
    WScript.Echo "Removed existing database."
End If

' --- Create the empty database via ADOX catalog ---
Set catalog = CreateObject("ADOX.Catalog")
catalog.Create "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & dbPath & ";"
WScript.Echo "Created database: " & dbPath

' --- Open an ADO connection to run DDL/DML ---
Set conn = CreateObject("ADODB.Connection")
conn.Open "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & dbPath & ";"

' --- Create Users table ---
conn.Execute _
    "CREATE TABLE Users (" & _
    "  UserId      AUTOINCREMENT PRIMARY KEY, " & _
    "  Username    TEXT(50) NOT NULL, " & _
    "  Password    TEXT(50) NOT NULL" & _
    ")"
WScript.Echo "Created table: Users"

' --- Create Customers table ---
conn.Execute _
    "CREATE TABLE Customers (" & _
    "  CustomerId  AUTOINCREMENT PRIMARY KEY, " & _
    "  FirstName   TEXT(50) NOT NULL, " & _
    "  LastName    TEXT(50) NOT NULL, " & _
    "  Email       TEXT(100), " & _
    "  Phone       TEXT(20), " & _
    "  CreatedDate DATETIME" & _
    ")"
WScript.Echo "Created table: Customers"

' --- Seed Users ---
conn.Execute "INSERT INTO Users (Username, [Password]) VALUES ('admin', 'admin123')"
conn.Execute "INSERT INTO Users (Username, [Password]) VALUES ('user', 'user123')"
WScript.Echo "Seeded Users (admin/admin123, user/user123)"

' --- Seed Customers ---
Dim sampleData, i
sampleData = Array( _
    Array("John",    "Smith",    "john.smith@example.com",    "(555) 123-4567"), _
    Array("Mary",    "Johnson",  "mary.johnson@example.com",  "(555) 234-5678"), _
    Array("Robert",  "Williams", "robert.w@example.com",      "(555) 345-6789"), _
    Array("Patricia","Brown",    "patricia.brown@example.com","(555) 456-7890"), _
    Array("Michael", "Davis",    "michael.davis@example.com", "(555) 567-8901"), _
    Array("Linda",   "Miller",   "linda.miller@example.com",  "(555) 678-9012"), _
    Array("James",   "Wilson",   "james.wilson@example.com",  "(555) 789-0123"), _
    Array("Barbara", "Moore",    "barbara.moore@example.com", "(555) 890-1234") _
)

For i = 0 To UBound(sampleData)
    conn.Execute _
        "INSERT INTO Customers (FirstName, LastName, Email, Phone, CreatedDate) VALUES (" & _
        "'" & sampleData(i)(0) & "', " & _
        "'" & sampleData(i)(1) & "', " & _
        "'" & sampleData(i)(2) & "', " & _
        "'" & sampleData(i)(3) & "', " & _
        "Now())"
Next
WScript.Echo "Seeded " & (UBound(sampleData) + 1) & " customers."

conn.Close
Set conn = Nothing
Set catalog = Nothing

WScript.Echo ""
WScript.Echo "Database creation complete: " & dbPath
