# Customer Management System (VB6)
### A representative legacy application for VB6 → VB.NET migration testing

This is a deliberately realistic VB6 desktop application built to stress a
VB6 → VB.NET migration pipeline. It is **not** a toy CRUD demo — it spans a
UI layer, a business layer, a data-access layer, two referenced ActiveX DLLs,
an Access database accessed through ADO, global state, configuration-file
reading, a menu system, and form-to-form communication.

---

## 1. Architecture

The application is layered:

```
┌─────────────────────────────────────────────────────────┐
│  UI LAYER (Forms)                                         │
│  frmLogin · frmMain · frmCustomer · frmSearch · frmAbout  │
└───────────────┬───────────────────────────────────────────┘
                │ calls
┌───────────────▼───────────────────────────────────────────┐
│  BUSINESS LAYER                                            │
│  CustomerService.cls                                       │
│   ├─ uses CustomerValidation.dll  (validation)             │
│   ├─ uses AuditLogger.dll          (logging)               │
│   └─ uses CustomerDAL              (persistence)           │
└───────────────┬───────────────────────────────────────────┘
                │ calls
┌───────────────▼───────────────────────────────────────────┐
│  DATA ACCESS LAYER                                         │
│  CustomerDAL.cls · UserDAL.cls · DbConnection.cls          │
│   └─ ADO (ADODB.Connection / Command / Recordset)          │
└───────────────┬───────────────────────────────────────────┘
                │ OLE DB (Jet 4.0)
┌───────────────▼───────────────────────────────────────────┐
│  DATABASE:  CustomerMS.mdb  (Microsoft Access)             │
│  Tables: Users, Customers                                  │
└─────────────────────────────────────────────────────────┘

Shared modules: modGlobals (global state) · modConfig (config I/O) · modMain (Sub Main)
Referenced ActiveX DLLs: CustomerValidation.dll · AuditLogger.dll
```

---

## 2. Folder structure

```
CustomerMS/
├── App/                          Main EXE project
│   ├── CustomerMS.vbp            Project file (references both DLLs + ADO)
│   ├── frmLogin.frm              Login form
│   ├── frmMain.frm               Dashboard + menu system
│   ├── frmCustomer.frm           Add/Edit maintenance form
│   ├── frmSearch.frm             Search form
│   ├── frmAbout.frm              About dialog
│   ├── Customer.cls              Business entity
│   ├── CustomerService.cls       Business layer
│   ├── CustomerDAL.cls           Customer data access (ADO)
│   ├── UserDAL.cls               Authentication data access
│   ├── DbConnection.cls          ADO connection management
│   ├── modGlobals.bas            Global variables / shared state
│   ├── modConfig.bas             Config-file reading (file I/O)
│   ├── modMain.bas               Sub Main entry point
│   └── app.config.txt            Runtime configuration
│
├── DLLs/
│   ├── CustomerValidation/       ActiveX DLL project
│   │   ├── CustomerValidation.vbp
│   │   └── CustomerValidator.cls ValidateEmail/Phone/Customer
│   └── AuditLogger/              ActiveX DLL project
│       ├── AuditLogger.vbp
│       └── Logger.cls            LogInfo/LogWarning/LogError + file I/O
│
├── Database/
│   ├── CreateDatabase.vbs        Builds CustomerMS.mdb + sample data
│   └── Schema.sql                Schema reference + migration notes
│
└── Docs/
    └── (this README + migration guide)
```

---

## 3. Database schema

**Users**

| Column   | Type          | Notes              |
|----------|---------------|--------------------|
| UserId   | AUTOINCREMENT | Primary key        |
| Username | TEXT(50)      | Login name         |
| Password | TEXT(50)      | Plain text (legacy)|

**Customers**

| Column      | Type          | Notes        |
|-------------|---------------|--------------|
| CustomerId  | AUTOINCREMENT | Primary key  |
| FirstName   | TEXT(50)      | Required     |
| LastName    | TEXT(50)      | Required     |
| Email       | TEXT(100)     |              |
| Phone       | TEXT(20)      |              |
| CreatedDate | DATETIME      | Set on insert|

Sample logins seeded by the script: `admin / admin123` and `user / user123`.

---

## 4. Build instructions

> Requires Visual Basic 6.0 (IDE) on Windows, MDAC/ADO 2.8, and Jet 4.0.
> 32-bit. Run the IDE **as Administrator** so DLL registration succeeds.

### Step 1 — Create the database
```
cd CustomerMS\Database
cscript CreateDatabase.vbs
```
This produces `CustomerMS.mdb` in the `Database` folder with sample data.

### Step 2 — Build and register CustomerValidation.dll
1. Open `DLLs\CustomerValidation\CustomerValidation.vbp` in VB6.
2. **File → Make CustomerValidation.dll** (build into the same folder).
   VB6 registers it automatically on a successful make.

### Step 3 — Build and register AuditLogger.dll
1. Open `DLLs\AuditLogger\AuditLogger.vbp` in VB6.
2. **File → Make AuditLogger.dll**.

### Step 4 — Open and run the main application
1. Open `App\CustomerMS.vbp` in VB6.
2. If the two DLL references show as **MISSING** (Project → References),
   re-check them and browse to the DLLs you just built. The GUIDs in the
   `.vbp` are placeholders; VB6 will bind to the real type libraries once
   the DLLs are registered.
3. Press **F5** to run, or **File → Make CustomerMS.exe** to compile.

### Step 5 — Log in
Use `admin / admin123`. The dashboard lists the seeded customers.

---

## 5. Runtime behavior

- **Login** (frmLogin) authenticates against `Users` (max 3 attempts).
- **Dashboard** (frmMain) lists customers; menu + buttons route to actions.
- **Add/Edit** (frmCustomer) validates through CustomerValidation.dll,
  persists through CustomerService → CustomerDAL, and logs through
  AuditLogger.dll.
- **Search** (frmSearch) runs a parameterized LIKE query; double-click a
  result for a details message box.
- **About** (frmAbout) shows version info from global constants.
- An `audit.log` file is written next to the EXE.

---

## 6. Why this is a good migration test case

See `Docs/MIGRATION_TEST_GUIDE.md` for the full mapping of which language
features each file exercises and what your Phase 1 / Phase 2 pipeline should
extract and validate.
